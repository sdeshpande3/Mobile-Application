package com.sonali.news_iit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class Restore implements Serializable {
    private ArrayList<Sources> sourceList = new ArrayList<Sources>();
    private ArrayList<Articles> articleList = new ArrayList <Articles>();
    private ArrayList<String> categories = new ArrayList <String>();
    private int currentSource;
    private int currentArticle;

    public String getSource_name() {
        return source_name;
    }

    public void setSource_name(String source_name) {
        this.source_name = source_name;
    }

    private String source_name;

    public HashMap<String, Integer> getMenu_color() {
        return menu_color;
    }

    public void setMenu_color(HashMap<String, Integer> menu_color) {
        this.menu_color = menu_color;
    }

    private HashMap<String, Integer> menu_color = new HashMap<>();

    public ArrayList<Sources> getSourceList() {
        return sourceList;
    }

    public void setSourceList(ArrayList<Sources> sourceList) {
        this.sourceList = sourceList;
    }

    public ArrayList<Articles> getArticleList() {
        return articleList;
    }

    public void setArticleList(ArrayList<Articles> articleList) {
        this.articleList = articleList;
    }

    public ArrayList<String> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<String> categories) {
        this.categories = categories;
    }

    public int getCurrentSource() {
        return this.currentSource;
    }

    public void setCurrentSource(int currentSource) {
        this.currentSource = currentSource;
    }

    public int getCurrentArticle() {
        return this.currentArticle;
    }

    public void setCurrentArticle(int currentArticle) {
        this.currentArticle = currentArticle;
    }
}
