package com.sonali.news_iit;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AFragment extends Fragment {
    private static final String TAG = "AFragment";
    TextView headline, daate, author, content, pagenumber;
    ImageView img;
    Articles article;
    View v;
    int count;

    public static final String ARTICLE = "ARTICLE";
    public static final String INDEX = "INDEX";
    public static final String TOTAL = "TOTAL";

    public static final AFragment newInstance(Articles article, int index, int total)
    {
        AFragment f = new AFragment();
        Bundle bdl = new Bundle(1);
        bdl.putSerializable(ARTICLE, article);
        bdl.putInt(INDEX, index);
        bdl.putInt(TOTAL, total);
        f.setArguments(bdl);
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        article  = (Articles) getArguments().getSerializable(ARTICLE);
        count = getArguments().getInt(INDEX)+1;
        int total = getArguments().getInt(TOTAL);
        String lastLine = count+" of "+total;

        v = inflater.inflate(R.layout.afragment, container, false);
        headline = (TextView)v.findViewById(R.id.headline);
        daate = (TextView) v.findViewById(R.id.date);
        author = (TextView) v.findViewById(R.id.author);
        content = (TextView) v.findViewById(R.id.description);
        pagenumber = (TextView) v.findViewById(R.id.count);
        img = (ImageView) v.findViewById(R.id.img);

        pagenumber.setText(lastLine);

        //set headliine
        if(article.getaTitle() != null){
            headline.setText(article.getaTitle());
        }
        else{
            headline.setText("");
        }

        //set date
        if(article.getaPublishedAt() !=null && !article.getaPublishedAt().isEmpty()) {

            String sDate1 = article.getaPublishedAt();

            Date date1 = null;
            String pubdate = "";
            try {
                if(sDate1 != null){

                    date1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(sDate1);}
                String pattern = "MMM dd, yyyy HH:mm";
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
                pubdate = simpleDateFormat.format(date1);
                daate.setText(pubdate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        //set content
        if(article.getaDescription()!=null) {
            content.setText(article.getaDescription());
        }
        else{
            content.setText("");
        }

        //set author
        if(article.getaAuthor() != null) {
            author.setText(article.getaAuthor());
        }
        else{
            author.setText("");
        }

        author.setMovementMethod(new ScrollingMovementMethod());

        if(article.getaImageUrl()!=null){loadRemoteImage(article.getaImageUrl());}

        headline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(article.getaUrl()));
                startActivity(intent);
            }
        });


        content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(article.getaUrl()));
                startActivity(intent);
            }
        });


        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(article.getaUrl()));
                startActivity(intent);
            }
        });

        return v;
    }


    private  void loadRemoteImage(final String imageURL){

        if (imageURL != null) {
            Picasso picasso = new Picasso.Builder(getActivity()).listener(new Picasso.Listener() {
                @Override
                public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                    // Here we try https if the http image attempt failed
                    final String changedUrl = imageURL.replace("http:", "https:");
                    picasso.load(changedUrl)
                            .fit()
                            .centerCrop()
                            .error(R.drawable.person)
                            .placeholder(R.drawable.image)
                            .into(img);
                }
            }).build();
            picasso.load(imageURL)
                    .fit()
                    .centerCrop()
                    .error(R.drawable.person)
                    .placeholder(R.drawable.image)
                    .into(img);
        } else {
//            error might occur
//            Picasso.with(getActivity())
            Picasso.get().load(imageURL)
                    .fit()
                    .centerCrop()
                    .error(R.drawable.person)
                    .placeholder(R.drawable.image)
                    .into(img);
        }
    }
}
