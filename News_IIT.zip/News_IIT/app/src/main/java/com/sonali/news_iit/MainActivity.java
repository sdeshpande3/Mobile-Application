package com.sonali.news_iit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private DrawerLayout drawerlayout;
    private ListView drawlist;
    private ActionBarDrawerToggle mDrawerToggle;
    private static boolean serviceRunning = false;
    static final String ACTION_MSG_TO_SERVICE = "ACTION_MSG_TO_SERVICE";
    static final String ACTION_NEWS_STORY = "ACTION_NEWS_STORY";
    static final String ARTICLE_LIST = "ARTICLE_LIST";
    static final String SOURCE_ID = "SOURCE_ID";
    private ArrayList<SpannableString> srcList = new ArrayList <SpannableString>();
    private ArrayList<String> catList = new ArrayList <String>();
    private ArrayList<Sources> sourceArrayList = new ArrayList <Sources>();
    private ArrayList<Articles> articleArrayList = new ArrayList <Articles>();
    private HashMap<String, Sources> sourceDataMap = new HashMap<>();
    HashMap<String, Integer> mc = new HashMap<>();
    private Menu item;
    private NewsReceiver newsReceiver;
    private String currentNewsSource;
    private ArrayAdapter adapter;
    private MyPageAdapter pageAdapter;
    private List<Fragment> fragments;
    private ViewPager pager;
    private boolean stateFlag;
    private int currentSourcePointer;
    Restore restore;
    private int[] cols;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        restore = new Restore();
        drawerlayout = (DrawerLayout)findViewById(R.id.drawer);
        drawlist = (ListView)findViewById(R.id.listview);

        if(!serviceRunning &&  savedInstanceState == null) {
            Intent intent = new Intent(MainActivity.this, NService.class);
            startService(intent);
            serviceRunning = true;
        }
        Log.d(TAG,"STATUS " + serviceRunning);

//        if (savedInstanceState != null) {
//            //probably orientation change
//            restore = (Restore) savedInstanceState.getSerializable("restored");
//        }
        cols = getResources().getIntArray(R.array.rainbow);
        newsReceiver = new NewsReceiver();
        IntentFilter filter = new IntentFilter(MainActivity.ACTION_NEWS_STORY);
        registerReceiver(newsReceiver, filter);

        drawlist.setOnItemClickListener(
                new ListView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        pager.setBackgroundResource(0);
                        currentSourcePointer = position;
                        selectItem(position);
                    }
                }
        );

        mDrawerToggle = new ActionBarDrawerToggle(
                this,
                drawerlayout,
                R.string.open,
                R.string.close
        );

        adapter = new ArrayAdapter<>(this, R.layout.list_item, srcList);
        drawlist.setAdapter(adapter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        fragments = new ArrayList<>();

        pageAdapter = new MyPageAdapter(getSupportFragmentManager());

        pager = findViewById(R.id.viewpager);
        pager.setAdapter(pageAdapter);

        if (sourceDataMap.isEmpty() && savedInstanceState == null )
            new SourceDownloader(this, "").execute();
    }

    private void selectItem(int position) {
        currentNewsSource = srcList.get(position).toString();
        Intent intent = new Intent(MainActivity.ACTION_MSG_TO_SERVICE);
        intent.putExtra(SOURCE_ID, currentNewsSource);
        sendBroadcast(intent);
        drawerlayout.closeDrawer(drawlist);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggles
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        new SourceDownloader(this, item.getTitle().toString()).execute();
        drawerlayout.openDrawer(drawlist);
        Log.d(TAG, "onOptionsItemSelected: DrawLayout" + drawlist);
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        item=menu;
        if(stateFlag){
            item.add("All");
            for (String s : catList)
                item.add(s);
            Log.d(TAG, "onCreateOptionsMenu: items " +item);
        }
        setColor();
        return true;
    }

    private void reDoFragments(ArrayList<Articles> articles) {

        setTitle(currentNewsSource);
        for (int i = 0; i < pageAdapter.getCount(); i++)
            pageAdapter.notifyChangeInPosition(i);

        fragments.clear();
        Log.d(TAG, "reDoFragments: Articles Size" + articles.size());
        for (int i = 0; i < articles.size(); i++) {
            Articles a = articles.get(i);

            fragments.add(AFragment.newInstance(articles.get(i), i, articles.size()));
        }
        pageAdapter.notifyDataSetChanged();
        pager.setCurrentItem(0);
        articleArrayList = articles;
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(newsReceiver);
        Intent intent = new Intent(MainActivity.this, NewsReceiver.class);
        stopService(intent);
        super.onDestroy();
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        restore.setCategories(catList);
        restore.setSourceList(sourceArrayList);
        Log.d(TAG, "onSaveInstanceState:on save get value  "+pager.getCurrentItem());
        restore.setCurrentArticle(pager.getCurrentItem());
        restore.setCurrentSource(currentSourcePointer);
        restore.setArticleList(articleArrayList);
        restore.setMenu_color(mc);
        restore.setSource_name(currentNewsSource);
        outState.putSerializable("restored", restore);
        Log.d(TAG, "onSaveInstanceState: End of onsave");
    }


    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {

        super.onRestoreInstanceState(savedInstanceState);
        Restore restore1 = (Restore)savedInstanceState.getSerializable("restored");
        Log.d(TAG, "onRestoreInstanceState: HEREEEEEE " + restore1.getCurrentArticle());
        stateFlag = true;
        articleArrayList = restore1.getArticleList();
        catList = restore1.getCategories();
        sourceArrayList = restore1.getSourceList();
        mc=restore1.getMenu_color();
        currentNewsSource = restore1.getSource_name();

        for(int i=0;i<sourceArrayList.size();i++){
//            srcList.add(sourceArrayList.get(i).getsName());
//            sourceDataMap.put(sourceArrayList.get(i).getsName(), (Sources)sourceArrayList.get(i));
            String key = sourceArrayList.get(i).getsCategory();
            Integer color = mc.get(key);
            SpannableString spanString = new SpannableString(sourceArrayList.get(i).getsName());
            spanString.setSpan(new ForegroundColorSpan(color), 0, spanString.length(), 0);
            srcList.add(spanString);
            sourceDataMap.put(sourceArrayList.get(i).getsName(), (Sources) sourceArrayList.get(i));
        }

        drawlist.setOnItemClickListener(

                new ListView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        pager.setBackgroundResource(0);
                        currentSourcePointer = position;
                        selectItem(position);

                    }
                }
        );
        currentSourcePointer = restore1.getCurrentSource();
        adapter = new ArrayAdapter<>(this, R.layout.list_item, srcList);
        drawlist.setAdapter(adapter);
        if(articleArrayList.size()!=0) {
            pager.setBackgroundResource(0);
            setTitle(currentNewsSource);
            for (int i = 0; i < pageAdapter.getCount(); i++)
                pageAdapter.notifyChangeInPosition(i);

            fragments.clear();
            Log.d(TAG, "reDoFragments: Articles Size" + articleArrayList.size());
//        for (int i = 0; i < articles.size(); i++) {
            for (int i = 0; i < 100; i++) {
                Articles a = articleArrayList.get(i);

//            fragments.add(AFragment.newInstance(articles.get(i), i, articles.size()));
                fragments.add(AFragment.newInstance(articleArrayList.get(i), i, 100));
            }

            pageAdapter.notifyDataSetChanged();
            Log.d(TAG, "onRestoreInstanceState: adapter position" + restore1.getCurrentArticle());
            pager.setCurrentItem(restore1.getCurrentArticle());
        }
//        adapter.notifyDataSetChanged();
//        pager.setBackgroundResource(restore.getCurrentSource());
//        //currentSourcePointer = restore.getCurrentArticle();
//        pager.setCurrentItem(restore.getCurrentSource());
//        selectItem(restore.getCurrentSource());
//        pageAdapter.notifyDataSetChanged();
        //pager.setCurrentItem(restore.getCurrentArticle());
        //setTitle("News Gateway");
        Log.d(TAG, "onRestoreInstanceState: End of onrestore");

    }

    class NewsReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case ACTION_NEWS_STORY:
                    ArrayList<Articles> artList;
                    Log.d(TAG, "onReceive: HEY");
                    if (intent.hasExtra(ARTICLE_LIST)) {
                        artList = (ArrayList <Articles>) intent.getSerializableExtra(ARTICLE_LIST);
                        reDoFragments(artList);
                        Log.d(TAG, "onReceive: survived");
                    }
                    break;
            }
        }
    }

    public void setSources(ArrayList<Sources> sourceList, ArrayList<String> categoryList)
    {
        sourceDataMap.clear();
        srcList.clear();
        sourceArrayList.clear();

        //catList.addAll(categoryList);
        sourceArrayList.addAll(sourceList);

//        for(int i=0;i<sourceList.size();i++){
//            srcList.add(sourceList.get(i).getsName());
//            sourceDataMap.put(sourceList.get(i).getsName(), (Sources) sourceList.get(i));
//        }

        if(!item.hasVisibleItems()) {
            catList.clear();
            catList =categoryList;
            item.add("All");
            Collections.sort(categoryList);
            Log.d(TAG, "setSources: category" + categoryList);
            for (String s : categoryList)
                item.add(s);
            setColor();
        }
        srcList.clear();
        //set color
          for(int i=0;i<sourceList.size();i++)
            {
                String key = sourceList.get(i).getsCategory();
                Integer color = mc.get(key);
                SpannableString spanString = new SpannableString(sourceList.get(i).getsName());
                spanString.setSpan(new ForegroundColorSpan(color), 0, spanString.length(), 0);
                srcList.add(spanString);
                sourceDataMap.put(sourceList.get(i).getsName(), (Sources) sourceList.get(i));
            }

        adapter.notifyDataSetChanged();
    }

    public void setColor(){
        mc.clear();
        for(int i = 0; i < item.size(); i++) {
            MenuItem item1 = item.getItem(i);
            SpannableString spanString = new SpannableString(item.getItem(i).getTitle().toString());
            spanString.setSpan(new ForegroundColorSpan(cols[i]), 0,     spanString.length(), 0); //fix the color to white
            item1.setTitle(spanString);
            mc.put(item.getItem(i).getTitle().toString(),cols[i]);
        }
    }

    private class MyPageAdapter extends FragmentPagerAdapter {
        private long baseId = 0;

        public MyPageAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getItemPosition(@NonNull Object object) {
            return POSITION_NONE;
        }

        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Override
        public long getItemId(int position) {
            // give an ID different from position when position has been changed
            return baseId + position;
        }

        public void notifyChangeInPosition(int n) {
            // shift the ID returned by getItemId outside the range of all previous fragments
            baseId += getCount() + n;
        }
    }
}
