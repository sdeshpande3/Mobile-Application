package com.sonali.news_iit;

import java.io.Serializable;

public class Articles implements Serializable {
    String aAuthor;
    String aTitle;
    String aDescription;
    String aImageUrl;
    String aPublishedAt;
    String aUrl;

    public String getaAuthor() {
        return aAuthor;
    }

    public void setaAuthor(String aAuthor) {
        this.aAuthor = aAuthor;
    }

    public String getaTitle() {
        return aTitle;
    }

    public void setaTitle(String aTitle) {
        this.aTitle = aTitle;
    }

    public String getaDescription() {
        return aDescription;
    }

    public void setaDescription(String aDescription) {
        this.aDescription = aDescription;
    }

    public String getaImageUrl() {
        return aImageUrl;
    }

    public void setaImageUrl(String aImageUrl) {
        this.aImageUrl = aImageUrl;
    }

    public String getaPublishedAt() {
        return aPublishedAt;
    }

    public void setaPublishedAt(String aPublishedAt) {
        this.aPublishedAt = aPublishedAt;
    }

    public String getaUrl() {
        return aUrl;
    }

    public void setaUrl(String aUrl) {
        this.aUrl = aUrl;
    }
}
