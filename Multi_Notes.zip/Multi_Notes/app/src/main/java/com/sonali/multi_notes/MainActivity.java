package com.sonali.multi_notes;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class MainActivity extends AppCompatActivity implements Adapter.OnItemClicked,Adapter.OnItemLongClicked {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> listItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new AsyncTaskRunner().execute("Notedata.json");


        // pass the data from one activity to another
//        Intent intent = getIntent();
//        String msg1 = intent.getStringExtra("Heading");
//        String msg2 =  intent.getStringExtra("Description");
//        recyclerView.setAdapter();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.notes_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id  = item.getItemId();
//        int h = item.getItemId();
        if(id == R.id.add){
            Intent i = new Intent(MainActivity.this, EditActivity.class);
            startActivityForResult(i,1);
            return false;
        }
        if(id == R.id.help){
            Intent g = new Intent(MainActivity.this, AboutActivity.class);
            startActivityForResult(g, 1);
            return false;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 1) {
            if(resultCode == Activity.RESULT_OK){
                if(data.getExtras().containsKey("position")){
                    int position = data.getIntExtra("position",-1);
                    ListItem item = new ListItem("","","");
                    listItems.remove(position);
                    ListItem result = (ListItem) data.getSerializableExtra("Note");
                    item.setHeading(result.getHeading());
                    item.setDate_time(result.getDate_time());
                    item.setDesc(result.getDesc());
                    listItems.add(0,item);
                    adapter.notifyItemRemoved(position);
                    adapter.notifyItemInserted(0);
                    adapter.notifyItemChanged(position);
                }else {
                    ListItem result = (ListItem) data.getSerializableExtra("Note");
                    listItems.add(0,result);
                    adapter.notifyItemInserted(listItems.size() - 1);
                    adapter.notifyDataSetChanged();
                }
                this.setTitle("Multi Notes (" + listItems.size() + ")");
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }
    }//onActivityResult


    private void loadRecycleView(List<ListItem> listItems){
        recyclerView = (RecyclerView) findViewById(R.id.recycle);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter(listItems, this);
        ((Adapter) adapter).setOnClick(MainActivity.this);
        ((Adapter) adapter).setOnLongClick(MainActivity.this);
        recyclerView.setAdapter(adapter);
        this.setTitle("Multi Notes (" + listItems.size() + ")");
    }

    @Override
    public void onItemClick(int position) {
        // The onClick implementation of the RecyclerView item click
        //ur intent code here
        Intent i = new Intent(MainActivity.this, EditActivity.class);
        i.putExtra("position",position);
        i.putExtra("data",listItems.get(position));
        startActivityForResult(i,1);
    }

    @Override
    public boolean onItemLongClicked(final int position){
        String Title = listItems.get(position).getHeading();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int whichButton) {
                switch (whichButton) {
                    case DialogInterface.BUTTON_POSITIVE:
                        //Yes button clicked
                        listItems.remove(position);
                        adapter.notifyItemRemoved(position);
                        adapter.notifyDataSetChanged();
                        MainActivity.this.setTitle("Multi Notes (" + listItems.size() + ")");
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        //No button clicked
                        //Ignore
                        break;
                }
            }
        };
        new AlertDialog.Builder(this)
                .setTitle("Delete note '" + Title + "' ?")
                .setPositiveButton("YES", dialogClickListener)
                .setNegativeButton("NO", dialogClickListener).show();
        return true;
    }

    @Override
    public void onPause() {
        super.onPause();
        String jsonString = new Gson().toJson(listItems);
        FileUtil.create(MainActivity.this,"Notedata.json",jsonString);

    }

    private class AsyncTaskRunner extends AsyncTask<String, Void, String> {

        private String resp;
        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            String filename = params[0];
            try {
                boolean isFilePresent = FileUtil.isFilePresent(MainActivity.this, filename);
                if(isFilePresent) {
                    String jsonString = FileUtil.read(MainActivity.this, filename);
                    Log.d("ERROR" , jsonString);
                    resp = jsonString;
                } else {
                    boolean isFileCreated = FileUtil.create(MainActivity.this, filename, "{}");
                    if(isFileCreated) {
                        String jsonString = new Gson().toJson("");
                        FileUtil.create(MainActivity.this,filename,jsonString);
                        resp = jsonString;
                        Toast.makeText(MainActivity.this,"JSON Created",Toast.LENGTH_SHORT).show();
                    } else {
                        //show error or try again.
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return resp;
        }


        @Override
        protected void onPostExecute(String result) {
            // execution of result of Long time consuming operation
            progressDialog.dismiss();
            try {
                listItems = (ArrayList<ListItem>) new Gson().fromJson(result,
                        new TypeToken<ArrayList<ListItem>>() {
                        }.getType());
            }catch (Exception e){
                e.printStackTrace();
                listItems = new ArrayList<>();
            }
            Toast.makeText(MainActivity.this,"Process Completed",Toast.LENGTH_SHORT).show();
            loadRecycleView(listItems);
        }


        @Override
        protected void onPreExecute() {
            System.out.println("In onPreExecute");
            progressDialog = ProgressDialog.show(MainActivity.this,
                    "ProgressDialog",
                    "Loading Notes");
        }

    }
}
