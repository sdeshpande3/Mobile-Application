package com.sonali.multi_notes;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    private List<ListItem> listItems;
    private Context context;

    public Adapter(List<ListItem> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    //declare interface
    private OnItemClicked onClick;
    private OnItemLongClicked onLongClick;

    //make interface like this
    public interface OnItemClicked {
        void onItemClick(int position);
    }

    public interface OnItemLongClicked {
        public boolean onItemLongClicked(int position);
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder,final int i) {
        ListItem listItem = listItems.get(i);
        viewHolder.heading.setText(listItem.getHeading());
        viewHolder.date_time.setText(listItem.getDate_time());
        String Desc = listItem.getDesc();
        if(Desc.length()<80)
            viewHolder.desc.setText(Desc.substring(0, Math.min(Desc.length(), 80)));
        else
            viewHolder.desc.setText(Desc.substring(0, Math.min(Desc.length(), 80)) + "...");

        //Setting on click listner
        viewHolder.heading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClick.onItemClick(i);
            }
        });
        viewHolder.date_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClick.onItemClick(i);
            }
        });
        viewHolder.desc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClick.onItemClick(i);
            }
        });

        //Setting On Long Click Listiner
        viewHolder.heading.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                onLongClick.onItemLongClicked(i);
                return true;
            }
        });
        viewHolder.date_time.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                onLongClick.onItemLongClicked(i);
                return true;
            }
        });
        viewHolder.desc.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                onLongClick.onItemLongClicked(i);
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView heading;
        public TextView date_time;
        public TextView desc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            heading = (TextView) itemView.findViewById(R.id.heading);
            date_time = (TextView) itemView.findViewById(R.id.date_time);
            desc = (TextView) itemView.findViewById(R.id.desc);
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public void setOnClick(OnItemClicked onClick)
    {
        this.onClick=onClick;
    }

    public void setOnLongClick(OnItemLongClicked onLongClick)
    {
        this.onLongClick=onLongClick;
    }
}
