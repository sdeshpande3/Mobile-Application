package com.sonali.multi_notes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class EditActivity extends AppCompatActivity {
    private EditText e1;
    private EditText e2;
    int position=-1;
    ListItem listItem = new ListItem("","","");
    private boolean isExisting=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        e1 = (EditText)findViewById(R.id.edit1);
        e2 = (EditText) findViewById(R.id.edit2);
        Intent intent = getIntent();
        if(intent.getExtras()!=null) {
            if (intent.getExtras().containsKey("position")) {
                this.position = intent.getIntExtra("position", -1);
                this.listItem = (ListItem) intent.getSerializableExtra("data");
                e1.setText(listItem.getHeading());
                e2.setText(listItem.getDesc());
                isExisting = true;
            }
//            String e1check = e1.getText().toString();
//            String e2check = e2.getText().toString();
//            if(e1check.isEmpty()){
//                Toast.makeText(getApplicationContext(),"Enter Title",Toast.LENGTH_SHORT).show();
//            }
//            if(e2check.isEmpty()){
//                Toast.makeText(getApplicationContext(),"Enter Description",Toast.LENGTH_SHORT).show();
//            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.add_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id  = item.getItemId();
        if(id == R.id.save){
            String Title = e1.getText().toString().trim();
            String Desc = e2.getText().toString().trim();
            Date date = new Date();
            DateFormat df = new SimpleDateFormat("EEE MMM dd, hh:mm a");
            String time = df.format(date);

            if(isExisting) {
             if(checkIfNotChanged(Title,Desc)){
                 Intent returnIntent = new Intent();
                 setResult(Activity.RESULT_CANCELED, returnIntent);
                 finish();
             }else{
                saveExistingNote(Title,time,Desc);
             }
            }
            saveNewNote(Title,time,Desc);
            return false;
        }
        return super.onOptionsItemSelected(item);
    }


    private  boolean checkIfNotChanged(String Title,String Desc){
        return (Title.equals(listItem.getHeading()) && Desc.equals(listItem.getDesc()));

    }

    private void saveExistingNote(String Title,String date_time,String Desc){
        Intent i = new Intent(EditActivity.this, MainActivity.class);
        ListItem listItem = new ListItem(Title,date_time,Desc);
        i.putExtra("Note", listItem);
        i.putExtra("position",position);
        setResult(RESULT_OK,i);
        finish();
    }

    private void saveNewNote(String Title,String time, String Desc){
        Intent i = new Intent(EditActivity.this, MainActivity.class);
        ListItem listItem = new ListItem(Title,time,Desc);
        i.putExtra("Note", listItem);
        setResult(RESULT_OK,i);
        finish();
    }

    @Override
    public void onBackPressed() {
        final String Title = e1.getText().toString().trim();
        final String Desc = e2.getText().toString().trim();
        Date date = new Date();
        DateFormat df = new SimpleDateFormat("EEE MMM dd, hh:mm a");
        final String time = df.format(date);

        if(!checkIfNotChanged(Title,Desc)) {
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int whichButton) {
                    switch (whichButton) {
                        case DialogInterface.BUTTON_POSITIVE:
                            //Yes button clicked
                            if (isExisting) {
                                saveExistingNote(Title, time, Desc);
                            }
                            saveNewNote(Title, time, Desc);
                            break;

                        case DialogInterface.BUTTON_NEGATIVE:
                            //No button clicked
                            Intent returnIntent = new Intent();
                            setResult(Activity.RESULT_CANCELED, returnIntent);
                            finish();
                            break;
                    }
                }
            };

            new AlertDialog.Builder(this)
                    .setTitle("Your note is not saved!")
                    .setMessage("Save note '" + Title + "' ?")
                    .setPositiveButton("YES", dialogClickListener)
                    .setNegativeButton("NO", dialogClickListener).show();

        }else{
            Intent returnIntent = new Intent();
            setResult(Activity.RESULT_CANCELED, returnIntent);
            finish();
        }
    }
}
