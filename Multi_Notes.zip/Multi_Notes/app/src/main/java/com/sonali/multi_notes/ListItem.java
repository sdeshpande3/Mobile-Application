package com.sonali.multi_notes;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ListItem  implements Serializable {
    private String heading;
    private String date_time;
    private String desc;

    public ListItem(String heading, String date_time, String desc) {
        this.heading = heading;
        this.date_time = date_time;
        this.desc = desc;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public String getDate_time() {
        return date_time;
    }

    public void setDate_time(String date_time) {
        this.date_time = date_time;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
