package com.sonali.stockwatch;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.LauncherActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Selection;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Adapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import android.support.v4.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recycle;
    private RecyclerView.Adapter adapter;

    private List<ListItem> listItems;
    private List<Stock> stockList = new ArrayList<>();
    private static final String TAG = "MainActivity";
    String m_Text = "";
    private SwipeRefreshLayout swiper;
    private ConnectivityManager connManager;
    public NameDownloader nameDownloader;
    private boolean connected = false;

    private final static  String STOCK_UPDATE="UPDATE_STOCK";
    private final static  String STOCK_SEARCH="SEARCH_STOCK";

    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycle = (RecyclerView) findViewById(R.id.recycle);
        recycle.setHasFixedSize(true);
        recycle.setLayoutManager(new LinearLayoutManager(this));

        listItems = new ArrayList<>();
        nameDownloader = new NameDownloader();
        builder =  new AlertDialog.Builder(MainActivity.this);
        for (int i = 0; i < 10; i++) {
            ListItem listItem = new ListItem(
                    "STOCK " + (i + 1),
                    "Apple Inc.",
                    "135.72",
                    "▲ 0.38(0.28%)"
            );

            listItems.add(listItem);

        }
        adapter = new MyCustomAdapter(listItems, this);
        recycle.setAdapter(adapter);

        swiper = (SwipeRefreshLayout) findViewById(R.id.swiper);

        swiper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                doRefresh();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.stock, menu);
        return true;
    }

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    public boolean checkConnection() {

//        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        try {
            connManager = (ConnectivityManager) this
                    .getSystemService(Context.CONNECTIVITY_SERVICE);

            NetworkInfo networkInfo = connManager.getActiveNetworkInfo();
            connected = networkInfo != null && networkInfo.isAvailable() &&
                    networkInfo.isConnected();
            return connected;


        } catch (Exception e) {
            System.out.println("CheckConnectivity Exception: " + e.getMessage());
            Log.v("connectivity", e.toString());
        }
        return connected;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (checkConnection()) {
            if (id == R.id.options) {


            } else {
                builder.setTitle("No Network Connection");
                builder.setMessage("Stocks Cannot Be Added Without A Network Connection");
            }
        }
        return super.onOptionsItemSelected(item);
    }

    public void addStock() {
        builder.setTitle("Stock Selection");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        builder.setView(input);
        builder.setMessage("Please enter a Stock Symbol:").setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
//                    //inside this function
                m_Text = input.getText().toString();
                Toast.makeText(MainActivity.this, "Working", Toast.LENGTH_LONG).show();
                HashMap<String, String> result = nameDownloader.getMatchStock(m_Text);
                if (result.size() != 0) {
                    if(result.size() == 1){
                        if(checkDuplicate(m_Text)){
//                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//                            builder.setMessage("Stocks symbol "+m_Text+" is already displayed");
//                            builder.setTitle("Duplicate Stock");
//                            builder.setIcon(R.mipmap.ic_garbage);
//                            AlertDialog dialog1 = builder.create();
//                            dialog1.show();
                        } else
                        {
//                            doAsyncLoad1(m_Text, STOCK_SEARCH);
                        }
                    }
                    else{

                    }
                    Toast.makeText(MainActivity.this, "Resultant", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "No Resultant", Toast.LENGTH_LONG).show();
                }
            }
        }).setNegativeButton("Cancel", null);
        AlertDialog alert = builder.create();
        alert.show();

//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//
//        final EditText et = new EditText(this);
//        et.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);;
//        et.setFilters(new InputFilter[]{new InputFilter.AllCaps()});
//        et.setGravity(Gravity.CENTER_HORIZONTAL);
//
//        builder.setView(et);

//        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//
//            }
//        });
//        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//                // User cancelled the dialog
//            }
//        });
//
//        builder.setMessage("Please enter a stock symbol:");
//        builder.setTitle("Stock Selection");
//
//        AlertDialog dialog = builder.create();
//        dialog.show();
    }

    public boolean checkDuplicate(String m_Text){
        Stock temp=null;
        for(int i=0;i<stockList.size();i++)
        {
            temp=stockList.get(i);
            if(temp.getSymbol().equals(m_Text))
                return true;
        }
        return  false;
    }

    public void showNoStockFoundAlert(String symbol){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Data for stock symbol");
        builder.setTitle("Symbol Not Found: "+symbol);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

//    public void doRefresh(){
//        if(checkConnection()) {
//            for (int i = 0; i < stockList.size(); i++) {
//                String tempVar = stockList.get(i).getSymbol() + "," + stockList.get(i).getCompanyName();
//                stockList.remove(stockList.get(i));
//                doAsyncLoad1(tempVar, MainActivity.STOCK_UPDATE);
//            }
//            swiper.setRefreshing(false);
//        }
//        else{
//            AlertDialog.Builder builder = new AlertDialog.Builder(this);
//            builder.setMessage("Stocks cannot be refreshed without a network connection");
//            builder.setTitle("No Network Connection");
//            AlertDialog dialog = builder.create();
//            dialog.show();
//            swiper.setRefreshing(false);
//        }
//    }

}

