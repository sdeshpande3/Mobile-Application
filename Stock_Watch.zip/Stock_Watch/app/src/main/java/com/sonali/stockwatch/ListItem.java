package com.sonali.stockwatch;

public class ListItem {
    private String stock;
    private String company;
    private String price;
//    private String image;
    private String risepercent;

    public ListItem(String stock, String company, String price, String risepercent) {
        this.stock = stock;
        this.company = company;
        this.price = price;
//        this.image = image;
        this.risepercent = risepercent;
    }

    public String getStock() {
        return stock;
    }

    public String getCompany() {
        return company;
    }

    public String getPrice() {
        return price;
    }

//    public String getImage() { return image; }

    public String getRisepercent() {
        return risepercent;
    }
}
