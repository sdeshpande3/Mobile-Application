package com.sonali.stockwatch;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class MyCustomAdapter extends RecyclerView.Adapter<MyCustomAdapter.ViewHolder> {
    private List<ListItem> listItems;
    private Context context;
    private MainActivity mainActivity;

    public MyCustomAdapter(List<ListItem> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

//    public MyCustomAdapter(List<Stock> stockList,MainActivity mainActivity) {
//        this.stockList=stockList;
//        this.mainActivity=mainActivity;
//    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item, viewGroup, false);

//        itemView.setOnClickListener(mainActivity);
//        itemView.setOnLongClickListener(mainActivity);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        ListItem listItem = listItems.get(i);
        viewHolder.stock.setText(listItem.getStock());
        viewHolder.company.setText(listItem.getCompany());
        viewHolder.price.setText(listItem.getPrice());
        viewHolder.risepercent.setText(listItem.getRisepercent());
//        if(listItem.getPriceChange()>=0) {
//            String priceChange="▲ "+stock.getPriceChange()+" ("+listItem.getChangePercentage()+"%)";
//            viewHolder.priceChange.setText(priceChange);
//            viewHolder.priceChange.setTextColor(Color.GREEN);
//            viewHolder.stockSymbol.setTextColor(Color.GREEN);
//            viewHolder.price.setTextColor(Color.GREEN);
//            viewHolder.companyName.setTextColor(Color.GREEN);
//        }
//        else
//        {
//            String priceChange="▼ "+stock.getPriceChange()+" ("+listItem.getChangePercentage()+"%)";
//            viewHolder.priceChange.setText(priceChange);
//            viewHolder.priceChange.setTextColor(Color.RED);
//            viewHolder.stockSymbol.setTextColor(Color.RED);
//            viewHolder.price.setTextColor(Color.RED);
//            viewHolder.companyName.setTextColor(Color.RED);
//        }
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView stock;
        public TextView company;
        public TextView price;
        public TextView risepercent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            stock = (TextView)itemView.findViewById(R.id.stock);
            company = (TextView)itemView.findViewById(R.id.company);
            price = (TextView)itemView.findViewById(R.id.price);
            risepercent = (TextView)itemView.findViewById(R.id.risepercent);
        }
    }
}
