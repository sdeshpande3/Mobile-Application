package com.sonali.stockwatch;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.BindException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class NameDownloader {
    //hashmap...accessible from main activity
    public static HashMap<String, String> stockmap = new HashMap<>();
//    public MainActivity mainActivity;
    public  NameDownloader(){
        new DataFetch().execute();
    }

//    public HashMap<String,String> getMatchStock(String m_text) {
//    }
//    public NameDownloader(MainActivity ma){
//        mainActivity = ma;
//    }

    class DataFetch extends AsyncTask<Void, Void, Void> {
        String jdata = "";
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                URL url = new URL("https://api.iextrading.com/1.0/ref-data/symbols ");
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line = "";
                while (line != null) {
                    line = bufferedReader.readLine();
                    jdata = jdata + line;
                }
                JSONArray JA = new JSONArray(jdata);
                for (int i = 0; i < JA.length(); i++) {
                    JSONObject JO = (JSONObject) JA.get(i);
                    stockmap.put(JO.get("symbol").toString().trim(), JO.get("name").toString().trim());
                    Log.d("INFO" , "ADDED " + JO.get("symbol").toString());
                    //databaseHelper.addStock(stock);
//                singleParsed = "symbol:" + JO.get("symbol") + "\n" +)
//                               "name:" + JO.get("name") + "\n";
//                dataParsed = dataParsed + singleParsed;
//                Log.d("INFO","DATA " + singleParsed);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.d("INFO", "COMPLETED LOADING DATAT IN HASMMASP");
            //MainActivity.jdata.setText(this.dataParsed);  //instead of jdata add the list view after clicking on OK.
        }

    }

    public HashMap<String,String> getMatchStock(String key){
        HashMap<String,String> stocks = new HashMap<>();
        Log.d("INFO","SEARCHING " + key);
//        Iterator<String> iterator = stockmap.keySet().iterator();
//        while (iterator.hasNext()){
//            String nextSymbol = iterator.next();
//            if(nextSymbol.toUpperCase().contains(key.toUpperCase())){
//                stocks.put(nextSymbol,stockmap.get(nextSymbol));
//            }else{
//                Log.i("INFO","DID NOT MATCH " + nextSymbol);
//            }
//        }
//
//        Iterator<Map.Entry<String, String>> iterator1 = stockmap.entrySet().iterator();
//        while (iterator1.hasNext()){
//            Map.Entry<String, String> nextName = iterator1.next();
//            if(nextName.contains(entry.toUpperCase())){
//                stocks.put(nextName,stockmap.get(nextName));
//            }else{
//                Log.i("INFO","DID NOT MATCH " + nextName);
//            }
//
//
//        }
        String keyUp = key.toUpperCase();
        for(Map.Entry<String,String> entry : stockmap.entrySet()){
            String symbol = entry.getKey();
            String name = entry.getValue();
            if(symbol.toUpperCase().contains(keyUp)){
                stocks.put(symbol,stockmap.get(symbol));
            }else{
                if(name.toUpperCase().contains(keyUp)){
                    stocks.put(symbol,stockmap.get(symbol));
                }else{
                    Log.i("INFO","DID NOT MATCH " + keyUp);
                }
            }
        }
        return  stocks;
    }
}
