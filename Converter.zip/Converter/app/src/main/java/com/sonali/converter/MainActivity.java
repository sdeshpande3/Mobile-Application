package com.sonali.converter;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    TextView t3, t4, t5, t6;
    RadioButton rb1, rb2;
    Button bconvert;
    EditText edit;
    private String celsius = "Celsius Degrees:";
    private String fahrenheit = "Fahrenheit Degrees:";
    //boolean convert;
    double result;
    String content;
    String append = " ";
//    String save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t3 = findViewById(R.id.textView3);
        t4 = findViewById(R.id.textView4);
        t5 = findViewById(R.id.textView5);
        t6 = findViewById(R.id.textView6);
        rb1 = findViewById(R.id.button1);
        rb2 = findViewById(R.id.button2);
        t3.setMovementMethod(new ScrollingMovementMethod());
        //NumberFormat nf = NumberFormat.getInstance();
        bconvert = findViewById(R.id.convert);

        edit = findViewById(R.id.editText);
        if(savedInstanceState != null)
        {
            append = savedInstanceState.getString("Save");
        }

        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t4.setText(fahrenheit);
                t5.setText(celsius);
                edit.setText(" ");
                t6.setText(" ");
            }
        });
        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t4.setText(celsius);
                t5.setText(fahrenheit);
                edit.setText(" ");
                t6.setText(" ");
            }
        });
//        bconvert.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String ed = edit.getText().toString();
//                if(ed.isEmpty() && rb1.isChecked()){
//                    Toast.makeText(MainActivity.this, "Enter degrees in Fahrenhet", Toast.LENGTH_SHORT).show();
//                }
//                if(ed.isEmpty() && rb2.isChecked()){
//                    Toast.makeText(MainActivity.this, "Enter degrees in Celsius", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
    }

    public void convert(View v) {
        String ed = edit.getText().toString();
//        if(ed.isEmpty() && rb1.isChecked()){
//            Toast.makeText(MainActivity.this, "Enter degrees in Fahrenhet", Toast.LENGTH_SHORT).show();
//        }
//        if(ed.isEmpty() && rb2.isChecked()){
//            Toast.makeText(MainActivity.this, "Enter degrees in Celsius", Toast.LENGTH_SHORT).show();
//        }
        if (rb1.isChecked()) {
            if(ed.trim().isEmpty()){
                Toast.makeText(MainActivity.this, "Enter degrees in Fahrenhet", Toast.LENGTH_SHORT).show();
            }else{
            content = edit.getText().toString();
            double val = Double.parseDouble(content);
            result = (val - 32.0) / 1.8;
            //t6.setText(String.valueOf(result));
            String output = String.format("%.1f", result);
            t6.setText(output);
            String output1 = content + "F ==>" + output + "C";
            //t3.append(content + "C" + "==>" + String.format("%.1f", result) + "F" + "\n");
            append = output1 + "\n" + append;
            t3.setText(append);
        }
        }
        if (rb2.isChecked()) {
            if (ed.trim().isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter degrees in Celsius", Toast.LENGTH_SHORT).show();
            } else {
                content = edit.getText().toString();
                double val = Double.parseDouble(content);
                result = (val * 1.8) + 32;
                //t6.setText(String.valueOf(result));
                String output = String.format("%.1f", result);
                t6.setText(output);
                String output1 = content + "C ==>" + output + "F";
                //t3.append(content + "F" + "==>" + String.format("%.1f", result) + "C" + "\n");
                append = output1 + "\n" + append;
                t3.setText(append);
            }
        }
//        save = t3.getText().toString();
//        edit.setText(" ");
//        t6.setText(" ");
    }

    public void clear(View v) {
        t3.setText(" ");
        append = "";
        Toast.makeText(MainActivity.this, "Conversion History Cleared", Toast.LENGTH_SHORT).show();
    }

    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("Output", t3.getText().toString());
        outState.putString("Text1", t4.getText().toString());
        outState.putString("Text2", t5.getText().toString());
        outState.putString("Save", append);
//        outState.putString("Save", save);
//        outState.putAll();
        super.onSaveInstanceState(outState);
    }

    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        t3.setText(savedInstanceState.getString("Output"));
        t4.setText(savedInstanceState.getString("Text1"));
        t5.setText(savedInstanceState.getString("Text2"));
        append = savedInstanceState.getString("Save");
    }
}
