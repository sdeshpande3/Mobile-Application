package com.sonali.stockwatch.Util;

import com.sonali.stockwatch.Model.Stock;

public interface TaskComplete {

    public void onTaskComplete(Stock stock);
}
