package com.sonali.rewards;

import java.io.Serializable;
import java.util.List;

public class Student implements Serializable {
    String studentId;
    String firstName;
    String lastName;
    String username;
    String department;
    String storyy;
    String position;
    String password;
    String pointsToAward;
    String admin;
    String imageBytes;
    String location;
    List<Rewards> rewards;
    int totalPoints;

    public Student(int totalPoints,String studentId, String firstName, String lastName, String username, String department, String storyy, String position, String password, String pointsToAward, String admin, String imageBytes, String location, List<Rewards> rewards) {
        this.totalPoints = totalPoints;
        this.studentId = studentId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.department = department;
        this.storyy = storyy;
        this.position = position;
        this.password = password;
        this.pointsToAward = pointsToAward;
        this.admin = admin;
        this.imageBytes = imageBytes;
        this.location = location;
        this.rewards = rewards;
    }

    public int getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(int totalPoints) {
        this.totalPoints = totalPoints;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getStoryy() {
        return storyy;
    }

    public void setStoryy(String storyy) {
        this.storyy = storyy;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPointsToAward() {
        return pointsToAward;
    }

    public void setPointsToAward(String pointsToAward) {
        this.pointsToAward = pointsToAward;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public String getImageBytes() {
        return imageBytes;
    }

    public void setImageBytes(String imageBytes) {
        this.imageBytes = imageBytes;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<Rewards> getRewards() {
        return rewards;
    }

    public void setRewards(List<Rewards> rewards) {
        this.rewards = rewards;
    }
}
