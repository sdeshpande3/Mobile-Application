package com.sonali.rewards;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private LocationManager locationManager;
    private Location currentLocation;
    private Criteria criteria;

    private static int MY_LOCATION_REQUEST_CODE = 329;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sp;
    String place;
    ProgressBar progressBar;
    public String lastName1, firstName1, username1, location1, department1, position1, story1, imageBytes1,password,admin;
    int pointsToAward1;
    List<Rewards> rewardsList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        TextView tv = (TextView) this.findViewById(R.id.tap);
        CheckBox check = (CheckBox) findViewById(R.id.checkBox);
        progressBar = (ProgressBar)findViewById(R.id.loading_spinner);
        progressBar.setVisibility(View.INVISIBLE);

        //retireve from shared preferences
        sp = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        String value1 = sp.getString("Username", "");
        String value2 = sp.getString("Password", "");
        Log.d(TAG, "onCreate: Shared Username is: " + value1);
        Log.d(TAG, "onCreate: Shared Password is: " + value2);
        ((EditText) findViewById(R.id.username)).setText(value1);
        ((EditText) findViewById(R.id.password)).setText(value2);

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ProfileActivity.class);
                i.putExtra("Location", place);
                startActivity(i);
            }

        });

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        criteria = new Criteria();
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        criteria.setAccuracy(Criteria.ACCURACY_MEDIUM);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setSpeedRequired(false);
        //get location
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        LocationServices locationServices = new LocationServices(MainActivity.this,locationManager);
        place = locationServices.getPlace();
    }

    public void login(View v) {
        String sId = "A20428066";
        String uName = ((EditText) findViewById(R.id.username)).getText().toString();
        String pswd = ((EditText) findViewById(R.id.password)).getText().toString();
        //display progressbar
        progressBar.setVisibility(View.VISIBLE);
        new LoginAPIAsyncTask(this).execute(sId, uName, pswd);
        Log.d(TAG, "login: Username" + uName);
        Log.d(TAG, "login: Password" + pswd);
//        progressBar.setVisibility(View.INVISIBLE);
    }

    //created shared preferences
    public void itemClicked(View v){
        CheckBox check = (CheckBox)v;
        String uName1 = ((EditText) findViewById(R.id.username)).getText().toString();
        String pswd1 = ((EditText) findViewById(R.id.password)).getText().toString();
        if(check.isChecked()){
            //create shared preferences
            //sp=getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor Ed=sp.edit();
            Ed.putString("Username",uName1);
            Ed.putString("Password",pswd1);
            Ed.commit();
            Log.d(TAG, "itemClicked: Stored in shared preferences");
        }
    }

    public void set(String lastName, String firstName, String username,String password, String location, int pointsToAward, String department, String position, String story, String imageBytes,String admin, List<Rewards> rewardsList){
        this.lastName1 = lastName;
        this.firstName1 = firstName;
        this.username1 = username;
        this.password = password;
        this.location1 = location;
        this.pointsToAward1 = pointsToAward;
        this.department1 = department;
        this.position1 = position;
        this.story1 = story;
        this.imageBytes1 = imageBytes;
        this.admin = admin;
        this.rewardsList = rewardsList;
    }

    public void success(){
        Intent i = new Intent(getApplicationContext(), YourProfile.class);
        i.putExtra("password",password);
        i.putExtra("lastName", lastName1);
        i.putExtra("firstName", firstName1);
        i.putExtra("username", username1);
        i.putExtra("location", location1);
        i.putExtra("pointsToAward", pointsToAward1);
        i.putExtra("department", department1);
        i.putExtra("position", position1);
        i.putExtra("story", story1);
        i.putExtra("imageBytes", imageBytes1);
        i.putExtra("admin",admin);
        i.putExtra("REWARDS", (Serializable) rewardsList);
        int total = 0;
        for (int j=0;j<rewardsList.size();j++)
            total += rewardsList.get(j).getValue();
        i.putExtra("awarded",total);
        startActivity(i);
        progressBar.setVisibility(View.INVISIBLE);
    }
    public void toast(){
        progressBar.setVisibility(View.VISIBLE);
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast,
                (ViewGroup) findViewById(R.id.ly1));
        TextView text = (TextView) layout.findViewById(R.id.custom);
        text.setText("Unauthorized Username/Password");

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
        progressBar.setVisibility(View.INVISIBLE);
    }
}
