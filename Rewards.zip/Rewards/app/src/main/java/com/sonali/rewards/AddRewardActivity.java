package com.sonali.rewards;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AddRewardActivity extends AppCompatActivity {
    private static final String TAG="AddRewardActivity";
    public static int MAX_CHARS = 80;
    private TextView charCountText;
    EditText editText, marks;
    TextView name, award, dept, pos1,insert;
    AlertDialog.Builder alert;
    Student data;
    String username, pass;
    String target_id = "A20428066";
    String firstname, lastname;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_reward);

        editText = (EditText)findViewById(R.id.editText);
        charCountText = (TextView)findViewById(R.id.count);
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_CHARS)});

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_with_logo);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        name = (TextView)findViewById(R.id.nameid);
        award = (TextView) findViewById(R.id.awarded);
        dept = (TextView) findViewById(R.id.department);
        pos1 = (TextView)findViewById(R.id.position);
        insert = (TextView)findViewById(R.id.insert);
        marks = (EditText)findViewById(R.id.marks);

        alert = new AlertDialog.Builder(AddRewardActivity.this);
        username = getIntent().getStringExtra("username");
        pass = getIntent().getStringExtra("password");
        firstname = getIntent().getStringExtra("firstName");
        lastname = getIntent().getStringExtra("lastName");
        Intent i = getIntent();
        data = (Student) i.getSerializableExtra("STUDENT");
        setTitle(data.getUsername());

        name.setText(data.getLastName() + "," + data.getFirstName());
        award.setText("Points Awarded\n"+data.getPointsToAward());
        dept.setText("Department\n"+data.getDepartment());
        pos1.setText("Position"+data.getPosition());
        insert.setText(data.getStoryy());
        ImageView imageView = (ImageView)findViewById(R.id.imageView88);
        String imge1 = data.getImageBytes();
        if(imge1!=null) {
            byte[] imageBytes = Base64.decode(imge1, Base64.DEFAULT);
            Log.d("TA", "doConvert: Image byte array length: " + imge1.length());
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            Log.d("TA", "" + bitmap);
            imageView.setImageBitmap(bitmap);
        }
        addTextListener();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.addreward, menu);
        return true;
    }

    public void toast(){
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast,
                (ViewGroup) findViewById(R.id.ly1));
        TextView text = (TextView) layout.findViewById(R.id.custom);
        text.setText("Add Reward Succeeded");

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }

    private void addTextListener() {
        editText.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
                // Nothing to do here
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
                // Nothing to do here
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                int len = s.toString().length();
                String countText = "(" + len + " of " + MAX_CHARS + ")";
                charCountText.setText(countText);
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.save3){
            alert.setTitle("Add Rewards Points ?");
            alert.setIcon(R.drawable.logo);
            alert.setMessage("Add rewards for "+data.getUsername() + " ?").
                    setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface  dialog, int which) {
                            saveRewards();
                        }
                    }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //cancel
                }
            });
            AlertDialog alert1 = alert.create();
            alert1.show();
        }
        return super.onOptionsItemSelected(item);
    }

    public void sendResult(String s)
    {
        if(s=="FAILED")
        {
            Toast.makeText(this, "Some Error Occured", Toast.LENGTH_SHORT).show();
        }
        else{
            Log.d(TAG,"back to get profile------------");
            Intent i1 = new Intent(getApplicationContext(), Leaderboard.class);
            i1.putExtra("username",username);
            i1.putExtra("pass",pass);
            i1.putExtra("firstName", firstname);
            i1.putExtra("lastName", lastname);
            toast();
            startActivity(i1);
        }
    }

    public void saveRewards()
    {
        Log.d(TAG,"saveRewards-----------00");
        String points = marks.getText().toString();
        String comments = editText.getText().toString();
        try{
            //JSONObject js = new JSONObject(output_json);

            String target_username = data.getUsername();
            String target_name = data.getFirstName() + " " + data.getLastName();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            String target_currentDateandTime = sdf.format(new Date());
            new RewardsAPIAsyncTask(AddRewardActivity.this).execute(target_id, target_username, target_name, target_currentDateandTime, points, comments, target_id, username, pass);
        }catch (Exception e)
        {
            e.printStackTrace();
        }

    }

}
