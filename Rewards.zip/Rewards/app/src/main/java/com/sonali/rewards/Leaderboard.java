package com.sonali.rewards;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static android.content.ContentValues.TAG;

public class Leaderboard extends AppCompatActivity implements View.OnClickListener {

    RecyclerView recyclerViewleader;
    AdapterLeader adapterleader;
    List<Student> listitems;
    String username;
    String pass;
    String temp_username;
    String temp_password;
    String firstname, lastname;
    String c;
    Student data1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);
        setTitle("Inspirational Leaderboard");
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_with_logo);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        temp_username = getIntent().getStringExtra("username");
        temp_password = getIntent().getStringExtra("pass");

        recyclerViewleader = findViewById(R.id.recyclerviewleader);
        recyclerViewleader.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewleader.setHasFixedSize(true);

        username = getIntent().getStringExtra("username");
        pass = getIntent().getStringExtra("pass");
        firstname = getIntent().getStringExtra("firstName");
        lastname = getIntent().getStringExtra("lastName");
        Log.d(TAG, "onCreate: receiving" + firstname + lastname);

        new GetAllProfilesAPIAsyncTask(this).execute(username,pass);
    }

    public void sendResults(String s, String response) {
        Log.d(TAG, "Leader Board sendResults: " + response);
        listitems = new ArrayList<>();
        try {

            JSONArray obj = new JSONArray(response);

            for (int i=0;i<obj.length();i++){
                int totalPoints = 0;
                JSONObject jsonObject = obj.getJSONObject(i);
                List<Rewards> list = new ArrayList<>();
                if(jsonObject.has("rewards") && !jsonObject.isNull("rewards")) {
                    JSONArray rewardsArray = jsonObject.getJSONArray("rewards");

                    for (int j = 0; j < rewardsArray.length(); j++) {
                        JSONObject reward = rewardsArray.getJSONObject(j);
                        int points = (int) reward.getInt("value");
                        totalPoints += points;
                        list.add(new Rewards((String) reward.getString("studentId"), (String) reward.getString("username"), (String) reward.getString("name"),
                                (String) reward.getString("date"), (String) reward.getString("notes"), points));
                    }
                }
                Log.d(TAG,"USER NAME " + (String)jsonObject.getString("firstName") + " total points "+ totalPoints + " pointstoward " + (String)jsonObject.getString("pointsToAward"));
                Student student = new Student(totalPoints,(String)jsonObject.getString("studentId"),(String)jsonObject.getString("firstName"),(String)jsonObject.getString("lastName")
                ,(String)jsonObject.getString("username"),(String)jsonObject.getString("department"),(String)jsonObject.getString("story"),(String)jsonObject.getString("position"),(String)jsonObject.getString("password")
                ,(String)jsonObject.getString("pointsToAward"),(String)jsonObject.getString("admin"),(String)jsonObject.getString("imageBytes"),(String)jsonObject.getString("location"),list);
                listitems.add(student);
                Log.d(TAG,"SIZE :- " + listitems.size());
            }
            Collections.sort(listitems, new Comparator<Student>() {
                @Override
                public int compare(Student o1, Student o2) {
                    if(o1.getTotalPoints()==o2.getTotalPoints()){
                        return  o1.getLastName().compareTo(o2.getLastName())==1 ? -1 : 1;
                    }else{
                        return  o1.getTotalPoints() > o2.getTotalPoints() ? -1 : 1;
                    }
                }
            });
            adapterleader = new AdapterLeader(listitems, this, this);
            recyclerViewleader.setAdapter(adapterleader);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        int i = recyclerViewleader.getChildLayoutPosition(v);
        Student data = listitems.get(i);
        if (data.getUsername().equals(username)) {
            Toast toast=Toast.makeText(getApplicationContext(),"You cannot reward yourself",Toast.LENGTH_SHORT);
            toast.setMargin(50,50);
            toast.show();
            return;
        }
        Intent intent = new Intent(Leaderboard.this, AddRewardActivity.class);
//        intent.putExtra("profile_data", data);
//        intent.putExtra("username", username);
//        intent.putExtra("password", pass);
        intent.putExtra("STUDENT", data);
        intent.putExtra("username",temp_username);
        intent.putExtra("password",temp_password);
        intent.putExtra("firstName", firstname);
        intent.putExtra("lastName", lastname);
        startActivity(intent);
    }
}
