package com.sonali.rewards;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.method.ScrollingMovementMethod;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class YourProfile extends AppCompatActivity {
    private static final String TAG = "YourProfile";
    public TextView nameid, loc, awarded, department, position, points, insert, rewardhistory;
    public String un2;
    private String result, password, studentId, username1;
//    public CheckBox checkBox;
    String fn2, ln2, loc3, pos3, dpt2, stry1, imge1,pass,admin;
    List<Rewards> listrewards;

    private RecyclerView recyclerViewprofile;
    private RecyclerView.Adapter adapterprofile;
    int p2a2;
    int award = 0;
    List<Rewards> listitemprofile;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_profile);
        recyclerViewprofile = (RecyclerView)findViewById(R.id.recyclerviewyourprofile);
        recyclerViewprofile.setHasFixedSize(true);
        recyclerViewprofile.setLayoutManager(new LinearLayoutManager(this));
//        scroll.setMovementMethod(new ScrollingMovementMethod());

        listitemprofile = new ArrayList<>();
        Log.d(TAG, "onCreate: ListItem"+listitemprofile);
        Intent i = getIntent();
        nameid = (TextView) findViewById(R.id.nameid);
        loc = (TextView) findViewById(R.id.loc);
        awarded = (TextView) findViewById(R.id.awarded);
        department = (TextView) findViewById(R.id.department);
        position = (TextView) findViewById(R.id.position);
        points = (TextView) findViewById(R.id.points);
        insert = (TextView) findViewById(R.id.insert);
        rewardhistory = (TextView) findViewById(R.id.rewardhistory);
        imageView = (ImageView) findViewById(R.id.imageView88);
        try {
            listitemprofile = (List<Rewards>) i.getSerializableExtra("REWARDS");

            Log.d(TAG, "onCreate: before award");


            if (listitemprofile.size() > 0) {
                for (int j = 0; j < listitemprofile.size(); j++)
                    award += listitemprofile.get(j).getValue();
            }


            adapterprofile = new AdapterYourProfile(listitemprofile, this);

            recyclerViewprofile.setAdapter(adapterprofile);

            rewardhistory.setText("Reward History (" + listitemprofile.size() + ")");
            setTitle("Your Profile");
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setLogo(R.drawable.icon);
            getSupportActionBar().setDisplayUseLogoEnabled(true);

//        setContentView(R.layout.activity_update_profile);



            un2 = getIntent().getStringExtra("username");
            pass = getIntent().getStringExtra("password");
            fn2 = getIntent().getStringExtra("firstName");
            ln2 = getIntent().getStringExtra("lastName");
            loc3 = getIntent().getStringExtra("location");
            p2a2 = getIntent().getIntExtra("pointsToAward", 0);
            pos3 = getIntent().getStringExtra("position");
            dpt2 = getIntent().getStringExtra("department");
            stry1 = getIntent().getStringExtra("story");
            admin = getIntent().getStringExtra("admin");
            nameid.setText(ln2 + ", " + fn2 + " (" + un2 + ")");
            loc.setText(loc3);
            //awarded.setText("Points Awarded:\n"+p2a2);
            department.setText("Department:\n" + dpt2);
            position.setText("Position\n" + pos3);
            points.setText("Points to Award:\n" + p2a2);
            insert.setText("" + stry1);
            awarded.setText("Points Awarded\n" + award);
            //image passed from profile activity
            imge1 = getIntent().getStringExtra("imageBytes");
            if (imge1 != null) {
                byte[] imageBytes = Base64.decode(imge1, Base64.DEFAULT);
                Log.d("TA", "doConvert: Image byte array length: " + imge1.length());
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                Log.d("TA", "" + bitmap);
                imageView.setImageBitmap(bitmap);
            }
            //showResult(getIntent().getStringExtra("rewards"));
        }catch (Exception e){
            Log.d(TAG,"IN EXCCEPTION YOUR PROFILE USERNAME "+ getIntent().getStringExtra("username") + " password " + getIntent().getStringExtra("password"));
            new LoginAPIAsyncTask(this).execute("A20428066",getIntent().getStringExtra("username"), getIntent().getStringExtra("password"));

            //showResult(getIntent().getStringExtra("rewards"));
        }
        }
//            Log.d(TAG, "onCreate: Inside else of your profile");
//            String first, second, uid, location, awarded, dept, position, award, story;
//            first = getIntent().getStringExtra("firstName");
//            second = getIntent().getStringExtra("lastName");
//            uid = getIntent().getStringExtra("username");
//            location = getIntent().getStringExtra("location");
//            dept = getIntent().getStringExtra("department");
//            position = getIntent().getStringExtra("position");
//            story = getIntent().getStringExtra("story");
//
//            nameid.setText(second + ", " + first + " (" + uid + ") ");
//            loc.setText(location);
//            department.setText(dept);
//            insert.setText(story);




//        showResult();


    public void set(String lastName, String firstName, String username,String password, String location, int pointsToAward, String department, String position, String story, String imageString,String admin, List<Rewards> rewardsList){

        try {
            Log.d(TAG, "MAde A API Call");
            this.ln2 = lastName;
            this.fn2 = firstName;
            this.un2 = username;
            this.pass = password;
            this.loc3 = location;
            this.p2a2 = pointsToAward;
            this.dpt2 = department;
            this.pos3 = position;
            this.stry1 = story;
            this.imge1 = imageString;
            this.admin = admin;
            this.listitemprofile = rewardsList;
            Log.d(TAG, "MAde A API Call LIST :- " + p2a2);
            nameid.setText(ln2 + ", " + fn2 + " (" + un2 + ")");
            loc.setText(loc3);
            Log.d(TAG,dpt2 + " " + imge1);
            //awarded.setText("Points Awarded:\n"+p2a2);
            this.department.setText("Department:\n" + dpt2);
            this.position.setText("Position\n" + pos3);
            points.setText("Points to Award:\n" + p2a2);
            insert.setText("" + stry1);
            awarded.setText("Points Awarded\n" + award);
            //image passed from profile activity
            //imge1 = getIntent().getStringExtra("imageBytes");
            if (imge1 != null) {
                byte[] imageBytes = Base64.decode(imge1, Base64.DEFAULT);
                Log.d("TA", "doConvert: Image byte array length: " + imge1.length());
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                Log.d("TAAAA", "" + "" + bitmap);
                imageView.setImageBitmap(bitmap);
            }
            rewardhistory.setText("Reward History (" + listitemprofile.size() + ")");
            adapterprofile = new AdapterYourProfile(listitemprofile, this);

            recyclerViewprofile.setAdapter(adapterprofile);
        }catch (Exception e){
            e.printStackTrace();
            throw  e;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id  = item.getItemId();
        if(id == R.id.sort){
            Intent i1 = new Intent(getApplicationContext(), Leaderboard.class);
            i1.putExtra("username",un2);
            i1.putExtra("pass",pass);
            i1.putExtra("lastName", ln2);
            i1.putExtra("firstName", fn2);
            startActivity(i1);
        }
        if(id == R.id.pencil){
            Intent intent = new Intent(getApplicationContext(), UpdateProfile.class);
            Log.d(TAG,"SENDING TO UPDATE :- " + p2a2);
            intent.putExtra("Constant username",un2);
            intent.putExtra("password",pass);
            intent.putExtra("lastName", ln2);
            intent.putExtra("firstName", fn2);
            intent.putExtra("location", loc3);
            intent.putExtra("pointsToAward", p2a2);
            intent.putExtra("department", dpt2);
            intent.putExtra("position", pos3);
            intent.putExtra("story", stry1);
            intent.putExtra("imageBytes", imge1);
            intent.putExtra("admin",admin);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.yourprofile, menu);
        return true;
    }

    public void showResult(String jsonResult)
    {
        try{
            int sum = 0;
            JSONArray store = new JSONArray();
            Log.d(TAG,"rewards list----------"+jsonResult);
            listrewards.clear();
            if(jsonResult!="null")
            {
                JSONArray j = new JSONArray(jsonResult);
                JSONArray ne = new JSONArray();
                if(j.length()>0)
                {

                    for(int k = 0; k < j.length(); k++)
                    {
                        JSONObject kj = j.getJSONObject(k);
                        kj.put("name",kj.getString("name"));
                        kj.put("date", kj.getString("date"));
                        kj.put("value",kj.getString("value"));
                        kj.put("comments",kj.getString("notes"));
                        sum = sum + Integer.parseInt(kj.getString("value"));
                        ne.put(kj);
                    }
                    setadapter(ne);
                }
            }
            points.setText(Integer.toString(sum));
        }catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(this, "Failed!", Toast.LENGTH_SHORT).show();
        }
    }

    public void setadapter(JSONArray js1){
        try{
            for(int k=0; k<js1.length();k++){
                JSONObject js = js1.getJSONObject(k);
                Rewards re = new Rewards();
                re.setDate(String.valueOf(js.getString("date")));
                re.setName(js.getString("name"));
                re.setValue(js.getInt("value"));
                re.setNotes(js.getString("notes"));
                listrewards.add(re);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

}
