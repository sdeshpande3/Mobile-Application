package com.sonali.rewards;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Locale;

import static android.content.ContentValues.TAG;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;
import static com.sonali.rewards.ProfileActivity.makeCustomToast;

public class UpdateProfile extends AppCompatActivity {
    EditText e_edit, epass, efirstname, esecondname, edepartment, epos;
    String location,imageString;
    AlertDialog.Builder alert;
    private File currentImageFile;
    int points;
    CheckBox eadm;
    TextView euser;
    private static final int PICK_FROM_GALLERY = 1;
    private static final int PICK_FROM_CAMERA = 100;
    private int REQUEST_IMAGE_GALLERY = 1;
    private int REQUEST_IMAGE_CAPTURE = 2;
    ImageView eimageviewplus, eimage;
    public static int MAX_CHARS = 360;
    TextView counting;
    public String imge1;
    public String admin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        setTitle("Edit Profile");
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_with_logo);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        e_edit = (EditText)findViewById(R.id.e_edit);
        euser = (TextView)findViewById(R.id.euser);
        epass = (EditText)findViewById(R.id.epass);
        efirstname = (EditText)findViewById(R.id.efirstname);
        esecondname = (EditText)findViewById(R.id.esecondname);
        edepartment = (EditText)findViewById(R.id.edepartment);
        epos = (EditText)findViewById(R.id.epos);
        eadm = (CheckBox)findViewById(R.id.eadm);
        counting = (TextView)findViewById(R.id.etextCount);
        addTextListener();

        eimage = (ImageView)findViewById(R.id.eimageView);
        eimageviewplus = (ImageView)findViewById(R.id.eplus);
        alert = new AlertDialog.Builder(UpdateProfile.this);

        e_edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(360)});

        String un2 = getIntent().getStringExtra("Constant username");
        String pass = getIntent().getStringExtra("password");
        String firstName= getIntent().getStringExtra("firstName");
        String lastName= getIntent().getStringExtra("lastName");
        location= getIntent().getStringExtra("location");
        points=getIntent().getIntExtra("pointsToAward",0);
        String position=getIntent().getStringExtra("position");
        String department=getIntent().getStringExtra("department");
        String story=getIntent().getStringExtra("story");
        imageString = getIntent().getStringExtra("imageBytes");
        imge1 = imageString;
        String admin = getIntent().getStringExtra("admin");
        if(admin.trim().equals("false")){
            eadm.setChecked(false);
        }else{
            eadm.setChecked(true);
        }
        euser.setText(un2.trim());
        epass.setText(pass.trim());
        efirstname.setText(firstName);
        esecondname.setText(lastName);
        epos.setText(position);
        edepartment.setText(department);
        e_edit.setText(story);
        ImageView eimageView = (ImageView)findViewById(R.id.eimageView);
        if(imageString!=null) {
            byte[] imageBytes = Base64.decode(imageString, Base64.DEFAULT);
            Log.d("TA", "doConvert: Image byte array length: " + imageString.length());
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            Log.d("TA", "" + bitmap);
            eimageView.setImageBitmap(bitmap);
        }

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        eimageviewplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    alert.setTitle("Profile Picture");
                    alert.setIcon(R.drawable.logo);
                    alert.setMessage("Take picture from:").
                            setPositiveButton("Camera", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    doCamera();
                                }
                            }).setNegativeButton("Gallery", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            doGallery();
                        }
                    }).setNeutralButton("Cancel", null);
                    AlertDialog alert1 = alert.create();
                    alert1.show();

            }
    });
}
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults)
    {
        switch (requestCode) {
            case PICK_FROM_GALLERY:
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(galleryIntent, PICK_FROM_GALLERY);
                } else {
                    //do something like displaying a message that he didn`t allow the app to access gallery and you wont be able to let him select from gallery
                }
                break;
            case PICK_FROM_CAMERA:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(galleryIntent, PICK_FROM_CAMERA);
                }
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.update, menu);
        return true;
    }

    public void toast(){
        Toast.makeText(this, "Profile Updated Successfully",
                Toast.LENGTH_LONG).show();
    }

    public void doCamera() {
        currentImageFile = new File(getExternalCacheDir(), "appimage_" + System.currentTimeMillis() + ".jpg");
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(currentImageFile));
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }

    public void doGallery() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, REQUEST_IMAGE_GALLERY);
        }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_IMAGE_GALLERY && resultCode == RESULT_OK) {
        try {
        processGallery(data);
        doConvert();
        } catch (Exception e) {
        Toast.makeText(this, "onActivityResult: " + e.getMessage(), Toast.LENGTH_LONG).show();
        e.printStackTrace();
        }
        } else if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
        try {
        processCamera();
        doConvert();
        } catch (Exception e) {
        Toast.makeText(this, "onActivityResult: " + e.getMessage(), Toast.LENGTH_LONG).show();
        e.printStackTrace();
        }
        }
        }

    private void processCamera() {
        Uri selectedImage = Uri.fromFile(currentImageFile);
        eimage.setImageURI(selectedImage);
        Bitmap bm = ((BitmapDrawable)eimage.getDrawable()).getBitmap();
        makeCustomToast(this,
        String.format(Locale.getDefault(), "%,d", bm.getByteCount()),
        Toast.LENGTH_LONG);

        currentImageFile.delete();
        }

    private void processGallery(Intent data) {
        Uri galleryImageUri = data.getData();
        if (galleryImageUri == null)
        return;

        InputStream imageStream = null;
        try {
        imageStream = getContentResolver().openInputStream(galleryImageUri);

        } catch (FileNotFoundException e) {
        e.printStackTrace();
        }

        final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

        Bitmap selectedImage1 = getResizedBitmap(selectedImage,100);
        eimage.setImageBitmap(selectedImage1);
        makeCustomToast(this,
        String.format(Locale.getDefault(), "%,d", selectedImage.getByteCount()),
        Toast.LENGTH_LONG);

        }

        public void doConvert() {
        if (eimage.getDrawable() == null)
            return;

        Bitmap origBitmap = ((BitmapDrawable) eimage.getDrawable()).getBitmap();

        ByteArrayOutputStream bitmapAsByteArrayStream = new ByteArrayOutputStream();
        origBitmap.compress(Bitmap.CompressFormat.JPEG, 75, bitmapAsByteArrayStream);
        makeCustomToast(this,
                String.format(Locale.getDefault(), "%,d", bitmapAsByteArrayStream.size()),
                Toast.LENGTH_LONG);

        String imgString = Base64.encodeToString(bitmapAsByteArrayStream.toByteArray(), Base64.DEFAULT);
        Log.d("conv", "doConvert: Image in Base64 size: " + imgString.length());
        imge1=imgString;
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 0) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        final String user = ((TextView)findViewById(R.id.euser)).getText().toString();
        final String pass = ((EditText)findViewById(R.id.epass)).getText().toString();
        final String first = ((EditText)findViewById(R.id.efirstname)).getText().toString();
        final String second = ((EditText)findViewById(R.id.esecondname)).getText().toString();
        final String dept = ((EditText)findViewById(R.id.edepartment)).getText().toString();
        final String pos = ((EditText)findViewById(R.id.epos)).getText().toString();
        final String edit = ((EditText)findViewById(R.id.e_edit)).getText().toString();
        admin = "false";
        boolean admin_check = ((CheckBox)findViewById(R.id.eadm)).isChecked();

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        LocationServices locationServices = new LocationServices(UpdateProfile.this,locationManager);
        final String place = locationServices.getPlace();

        if(admin_check){
            admin = "true";
        }else{
            admin="false";
        }
        if(id == R.id.save2){
            alert.setTitle("Save Changes?");
            alert.setIcon(R.drawable.logo).
                    setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                     new UpdateProfileAPIAsyncTask(UpdateProfile.this).execute("A20428066", user, pass,first, second, points+ "",dept, edit, pos, admin, place, imge1);
                     Intent intent1 = new Intent(getApplicationContext(), YourProfile.class);
                     intent1.putExtra("lastName", second);
                     intent1.putExtra("firstName", first);
                     intent1.putExtra("username", user);
                     intent1.putExtra("password",pass);
                     intent1.putExtra("location", location);
                     intent1.putExtra("department", dept);
                     intent1.putExtra("position", pos);
                     intent1.putExtra("story", edit);
                            customtoast1();
                            startActivity(intent1);

                        }
                    }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //cancel
                }
            });
            AlertDialog alert1 = alert.create();
            alert1.show();

        }

        //back press
        if(id == android.R.id.home){
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void customtoast1(){
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast,
                (ViewGroup) findViewById(R.id.ly1));
        TextView text = (TextView) layout.findViewById(R.id.custom);
        text.setText("User Update Successful");

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }

    public void sendResults(String s, String response) {
        Log.d(TAG, "sendResults: " + response);
    }

    private void addTextListener() {
            e_edit.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
                // Nothing to do here
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
                // Nothing to do here
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                int len = s.toString().length();
                String countText = "(" + len + " of " + MAX_CHARS + ")";
                counting.setText(countText);
            }
        });
    }
}
