package com.sonali.rewards;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;


public class AdapterLeader extends RecyclerView.Adapter<AdapterLeader.ViewHolder> {

    private static final String TAG = "AdapterLeader";
    private List<Student> listItemLeaders;
    Context context;
    Leaderboard leaderboard;

    public AdapterLeader(List<Student> listItemLeaders, Context context,Leaderboard leaderboard) {
        this.listItemLeaders = listItemLeaders;
        this.context = context;
        this.leaderboard=leaderboard;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item_leader, viewGroup, false);
        v.setOnClickListener((View.OnClickListener) context);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        String c = leaderboard.lastname + "," + leaderboard.firstname;
        Log.d("Aadi", "onBindViewHolder: Receiving c" + c);
        Student listItem = listItemLeaders.get(i);
        Log.d(TAG,listItem.getUsername() + " " + listItem.getPassword());
        viewHolder.leaderimage1.setImageBitmap(getBitmap(listItem.getImageBytes()));
        viewHolder.namepoints1.setText(listItem.getLastName() + "," + listItem.getFirstName() + "          " + listItem.totalPoints);
        viewHolder.posdept1.setText(listItem.getPosition() + "," + listItem.getDepartment());
        String d = listItem.getLastName() + "," + listItem.getFirstName();
        Log.d("Aadi", "onBindViewHolder: Print value of d:" + d);
        if(d.equals(c)){
            viewHolder.namepoints1.setTextColor(Color.parseColor("#008577"));
            viewHolder.posdept1.setTextColor(Color.parseColor("#008577"));
        }

    }

    private Bitmap getBitmap(String imge1) {
        try {
            Log.d(TAG, "getBitmap: " + String.valueOf(imge1));
            byte[] imageBytes = Base64.decode(imge1, Base64.DEFAULT);
            Log.d("TA", "doConvert: Image byte array length: " + imge1.length());
            //Log.d("TA", "" + bitmap);
            return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
        }catch (Exception e){
            Log.d(TAG,"IMPROPER IMAGE");
            return BitmapFactory.decodeResource(context.getResources(),
                    R.drawable.default_photo);
        }
        //imageView.setImageBitmap(bitmap)
    }

    @Override
    public int getItemCount() {
        return listItemLeaders.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView leaderimage1;
        public TextView namepoints1, posdept1;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            leaderimage1 = (ImageView) itemView.findViewById(R.id.leaderimage);
            namepoints1 = (TextView) itemView.findViewById(R.id.namepoints);
            posdept1 = (TextView) itemView.findViewById(R.id.posdept);


        }
    }
}
