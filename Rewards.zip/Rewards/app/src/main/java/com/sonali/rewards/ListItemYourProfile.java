package com.sonali.rewards;

public class ListItemYourProfile {
    private String datenamepoints1;
    private  String comments1;

    public ListItemYourProfile(String datenamepoints1, String comments1) {
        this.datenamepoints1 = datenamepoints1;
        this.comments1 = comments1;
    }

    public String getDatenamepoints1() {
        return datenamepoints1;
    }

    public String getComments1() {
        return comments1;
    }
}
