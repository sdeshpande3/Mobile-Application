package com.sonali.rewards;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import static java.net.HttpURLConnection.HTTP_OK;

public class RewardsAPIAsyncTask extends AsyncTask<String, Void, String> {
    AddRewardActivity rewardProfile;
    private static final String TAG = "AddRewards";
    private static final String baseUrl = "http://inspirationrewardsapi-env.6mmagpm2pv.us-east-2.elasticbeanstalk.com";
    private static final String loginEndPoint ="/rewards";

    public RewardsAPIAsyncTask(AddRewardActivity rewardProfile) {
        this.rewardProfile = rewardProfile;
    }
    @Override
    protected String doInBackground(String... strings) {
        String target_id = strings[0];
        String target_username = strings[1];
        String target_name = strings[2];
        String target_date = strings[3];
        String target_points = strings[4];
        String target_comments = strings[5];
        String source_id = strings[6];
        String source_username = strings[7];
        String source_password = strings[8];

        try{
            JSONObject main = new JSONObject();
            JSONObject target = new JSONObject();
            target.put("studentId",target_id);
            target.put("username", target_username);
            target.put("name", target_name);
            target.put("date", target_date);
            target.put("notes", target_comments);
            target.put("value",Integer.parseInt(target_points));

            main.put("target",target);

            JSONObject source = new JSONObject();
            source.put("studentId",source_id);
            source.put("username", source_username);
            source.put("password", source_password);

            main.put("source", source);
            Log.d(TAG,"JSON Object-----------"+main.toString());
            return doAPICall(main);
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String aVoid) {
        Log.d(TAG,"send result------------"+aVoid);
        if(aVoid.contains("error"))
        {
            rewardProfile.sendResult("FAILED");
        }
        else{
            Log.d(TAG,"send result23------------"+aVoid);
            rewardProfile.sendResult("SUCCESS");

        }
    }

    private String doAPICall(JSONObject jsonObject) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {

            String urlString = baseUrl + loginEndPoint;  // Build the full URL

            Uri uri = Uri.parse(urlString);    // Convert String url to URI
            URL url = new URL(uri.toString()); // Convert URI to URL

            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");  // POST - others might use PUT, DELETE, GET

            // Set the Content-Type and Accept properties to use JSON data
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.connect();

            // Write the JSON (as String) to the open connection
            OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
            out.write(jsonObject.toString());
            out.close();

            int responseCode = connection.getResponseCode();

            StringBuilder result = new StringBuilder();

            // If successful (HTTP_OK)
            if (responseCode == HTTP_OK) {

                // Read the results - use connection's getInputStream
                Log.d(TAG, "Sucesss message from responsecode----------");
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while (null != (line = reader.readLine())) {
                    result.append(line).append("\n");
                }

                // Return the results (to onPostExecute)
                Log.d(TAG, "result from response api-----------"+result.toString());
                return result.toString();

            } else {
                // Not HTTP_OK - some error occurred - use connection's getErrorStream
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                String line;
                while (null != (line = reader.readLine())) {
                    result.append(line).append("\n");
                }

                // Return the results (to onPostExecute)
                return result.toString();
            }

        } catch (Exception e) {
            // Some exception occurred! Log it.
            Log.d(TAG, "doAuth: " + e.getClass().getName() + ": " + e.getMessage());

        } finally { // Close everything!
            if (connection != null) {
                connection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    Log.e(TAG, "doInBackground: Error closing stream: " + e.getMessage());
                }
            }
        }
        return "Some error has occurred"; // Return an error message if Exception occurred
    }
}
