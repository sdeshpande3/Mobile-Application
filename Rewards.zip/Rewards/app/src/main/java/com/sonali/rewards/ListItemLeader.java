package com.sonali.rewards;

public class ListItemLeader {
    private String leaderimage1;
    private String namepoints1;
    private String posdept1;

    public ListItemLeader(String leaderimage1, String namepoints1, String posdept1) {
        this.leaderimage1 = leaderimage1;
        this.namepoints1 = namepoints1;
        this.posdept1 = posdept1;
    }

    public String getLeaderimage1() {
        return leaderimage1;
    }

    public String getNamepoints1() {
        return namepoints1;
    }

    public String getPosdept1() {
        return posdept1;
    }
}
