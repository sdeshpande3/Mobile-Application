package com.sonali.rewards;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class AdapterYourProfile extends RecyclerView.Adapter<AdapterYourProfile.ViewHolder> {

    private List<Rewards> listItemprofile;
    Context context;

    public AdapterYourProfile(List<Rewards> listItemprofile, Context context) {
        this.listItemprofile = listItemprofile;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item_your_profile, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Rewards listItemprofile1 = listItemprofile.get(i);
        viewHolder.datenamepoints1.setText(listItemprofile1.getDate() + "  " + listItemprofile1.getName() + "           " + listItemprofile1.getValue());
        viewHolder.comments1.setText(listItemprofile1.getNotes());
    }

    @Override
    public int getItemCount() {
        return listItemprofile.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView datenamepoints1;
        public TextView comments1;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            datenamepoints1 = (TextView)itemView.findViewById(R.id.datenamepoints);
            comments1 = (TextView)itemView.findViewById(R.id.comments);

        }
    }
}
